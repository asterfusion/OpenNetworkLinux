"""Wrapper for %(name)s

Generated with:
%(argv)s

Do not modify this file.
"""

__docformat__ = "restructuredtext"
