"""
ctypesgen.printer.printer imports this module so that it can find the path
to defaulttemplate.py and defaultloader.py.
"""

pass
