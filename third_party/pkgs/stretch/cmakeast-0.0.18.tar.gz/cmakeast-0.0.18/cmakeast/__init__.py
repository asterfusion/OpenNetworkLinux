# /cmakeast/__init__.py
#
# Entry point for linter.
#
# See /LICENCE.md for Copyright information
"""Init module for linter."""

import cmakeast.printer

if __name__ == "__main__":
    cmakeast.printer.main()
